import "./Footer.css";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import axios from 'axios'
const Footer = () => {
  const navigate = useNavigate();
  const [userEmial,setuserEmail] = useState('')
  const postEmail = () => {
    if(userEmial === ''){
      alert('please enter email')
      return
    }
    axios.post('https://119.91.31.118:7001/api/userManage/emailPost',{email:userEmial}).then(res=>{
      alert('email success send')
      console.log(res,'res')
    })
    console.log('aa',userEmial)
  }
  return (
    <>
      <div className="BigBox">
        <div className="TopHead">
          <span className="marginL"><span>SIGN</span>  <span>UP</span>   <span>FOR</span>  <span>OUR</span>  <span>DAILY</span>  <span>INSIDER</span></span>
          <span><input onChange={(e)=>{
            setuserEmail(e.target.value)
          }} className="emailbox" type='text' placeholder="Enter Your Email" /></span>
          <span><button onClick={()=>{
            postEmail()
          }}>Subscribe</button></span>
        </div>
        <div className="FooterBoxChild">
          <div className="HeadChild">
            <div className="HeadItem">
              <h2>Explore</h2>
              <span>Home</span>
              <span onClick={()=>{
                navigate('/toQuestionList')
              }}>Question</span>
              <span>Articles</span>
              <span>Tutorials</span>
            </div>
            <div className="HeadItem">
              <h2>Support</h2>
              <span>FAQs</span>
              <span>Help</span>
              <span>Contact Us</span>
              <span onClick={()=>{
                navigate('/Plan')
              }}>Plan</span>
            </div>
            <div className="HeadItem">
              <h2>Stay connected</h2>
              <span>
                <img
                  className="icon"
                  src={require("../../statis/images/Pictogram.png")}
                  alt=""
                ></img>
                <img
                  className="icon"
                  src={require("../../statis/images/Pictogram2.png")}
                  alt=""
                ></img>
                <img
                  className="icon"
                  src={require("../../statis/images/Pictogram3.png")}
                  alt=""
                ></img>
              </span>
            </div>
          </div>
          <div className="BottomChild">
            <div className="Info">Dev@Deakin 2022</div>
            <div className="Info Special">
              <div>Privacy Policy</div>
              <div>Terms</div>
              <div>Code of Conduct</div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Footer;
