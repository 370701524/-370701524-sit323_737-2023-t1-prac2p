import "./Login.css";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { useState, useEffect } from "react";
const Login = () => {
  let [email, setemail] = useState("");
  let [password, setpassword] = useState("");

  let [isLogin, setisLogin] = useState(false);
  let [UserName, setUserName] = useState("");
  let [UserEmail, setUserEmail] = useState("");
  useEffect(() => {
    if (localStorage.getItem("UserInfo")) {
      setisLogin(true);
      setUserName(JSON.parse(localStorage.getItem("UserInfo")).data.name);
      setUserEmail(JSON.parse(localStorage.getItem("UserInfo")).data.email);
    } else {
      setisLogin(false);
    }
  }, []);
  const navigate = useNavigate();
  const LoginOutUser = () => {
    localStorage.removeItem("UserInfo");
    setisLogin(false);
  };
  const LoginUser = () => {
    axios
      .post("https://119.91.31.118:7001/api/userManage/loginUser", {
        outType: 1,
        name: "initName",
        email: email,
        password: password,
      })
      .then((res) => {
        console.log(res, "rrrres");
        if (res.data.code === 200) {
          setisLogin(true);
          alert("登录成功");
          localStorage.setItem("UserInfo", JSON.stringify(res.data.data));
          navigate("/");
        } else {
          alert(res.data.data.msg);
          return;
        }
      });
  };
  return (
    <>
      <div className="LoginBox">
        <div className="Heads">
          <button className="signUpBtn">
            <Link to="/Regist">Sign Up</Link>
          </button>
        </div>
        {isLogin === true ? (
          <>
            <h3 className="specialH3">Your Are Login</h3>
          </>
        ) : (
          <>
            <h3 className="specialH3">Your Are Not Login</h3>
          </>
        )}
        {isLogin === true ? (
          <>
            <div className="specialH3">Your Name：{UserName}</div>
            <div className="specialH3">Your Email：{UserEmail}</div>
          </>
        ) : (
          <>
            <div className="Form">
              <div className="FormItem">
                <div>Your Email</div>
                <div>
                  <input
                    value={email}
                    onChange={(e) => {
                      setemail(e.target.value);
                    }}
                    className="inputL"
                    placeholder="Enter Your Email"
                    type="text"
                  />
                </div>
              </div>
              <div className="FormItem">
                <div>Your Password</div>
                <div>
                  <input
                    value={password}
                    onChange={(e) => {
                      setpassword(e.target.value);
                    }}
                    className="inputL"
                    placeholder="Enter Your Password"
                    type="password"
                  />
                </div>
              </div>
            </div>
          </>
        )}
        <div className="SingBtn">
          {isLogin === false ? (
            <>
              <button className="signIn" onClick={LoginUser}>
                Login
              </button>
            </>
          ) : (
            <>
              <button className="signIn" onClick={LoginOutUser}>
                Log Out
              </button>
            </>
          )}
        </div>
      </div>
    </>
  );
};

export default Login;
