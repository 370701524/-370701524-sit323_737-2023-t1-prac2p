import "./Farticle.css";
import { useState } from "react";
const FArticle = () => {
  let [article] = useState([
    {
      AImg: require("../../statis/images/Article image1.jpg"),
      AName: "Article's Name",
      ADescription: "Description _ _ _ _ _",
      ATag: "e.g.， React Or Vue",
      ALike: 5,
      AUserName: "Author's name",
    },
    {
      AImg: require("../../statis/images/Article image2.jpg"),
      AName: "Article's Name",
      ADescription: "Description _ _ _ _ _",
      ATag: "e.g.， NodeJS",
      ALike: 5,
      AUserName: "Author's name",
    },
    {
      AImg: require("../../statis/images/Article image3.jpg"),
      AName: "Article's Name",
      ADescription: "Description _ _ _ _ _",
      ATag: "e.g.， React Hook",
      ALike: 5,
      AUserName: "Author's name",
    },
  ]);
  return (
    <>
      <div className="FArticle">
        <div className="Typess">Featured Articles</div>
        <div className="ItemBox">
          {article.length > 0 &&
            article.map((item) => {
              return (
                <div className="EachItem" key={item.id}>
                  <div className="Top">
                    <img
                      className="articleImg"
                      src={item.AImg}
                      alt=""
                    ></img>
                  </div>
                  <div className="Bottom">
                    <div className="AName">{item.AName}</div>
                    <div className="ADescription">{item.ADescription}</div>
                    <div className="ATag">{item.ATag}</div>
                    <div className="ASplit"></div>
                    <div className="AInfo">
                      <div className="LeftB">
                        <img
                          className="star"
                          src={require("../../statis/images/star.png")}
                          alt=""
                        ></img>
                        <span className="ALike">{item.ALike}</span>
                      </div>
                      <div className="RightBss">{item.AUserName}</div>
                    </div>
                  </div>
                </div>
              );
            })}
        </div>
        <div className="AMore">
          <button className="SeeMore"> See all articles</button>
        </div>
      </div>
    </>
  );
};

export default FArticle;
