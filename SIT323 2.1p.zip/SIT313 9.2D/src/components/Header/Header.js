import "./Header.css";
import { Link } from "react-router-dom";
import { useEffect, useState } from "react";

const Header = (props) => {
  let [currentUserName, setCurrentUserName] = useState("");
  let [isLogin, setisLogin] = useState(false);
  useEffect(() => {
    judge()
  }, []);
  const judge = () => {
    if (localStorage.getItem("UserInfo")) {
      setCurrentUserName(
        JSON.parse(localStorage.getItem("UserInfo")).data.name
      );
      setisLogin(true);
    } else {
      setisLogin(false);
      setCurrentUserName(
        'Tourtist'
      );
    }
  }
  return (
    <>
      <div className="HeaderChild">
        <div className="Top">
          <span>
            {" "}
            Welcome{" "}
            <span className="user">
              {currentUserName === "" ? "Tourist" : currentUserName}
            </span>
          </span>
          <span>
            <input className="input" type="text" placeholder="Search" />
          </span>
          <span className="btnL">
            <Link to="/toPost">Post</Link>
          </span>
          {isLogin === true ? (
            <>
              <span className="btnL">
                <Link to="/Login">User</Link>
              </span>
              <a href="#" className="aa" onClick={()=>{
                localStorage.removeItem("UserInfo")
                judge()
                alert('Log Out Success')
              }}>LogOut</a>
            </>
          ) : (
            <>
              <span className="btnL">
                <Link to="/Login">Login</Link>
              </span>
            </>
          )}
        </div>
        <div className="Bottom">
          <img
            className="lunbo"
            src={require("../../statis/images/Image1.jpg")}
            alt=""
          ></img>
        </div>
      </div>
    </>
  );
};

export default Header;
