import "./Type.css";
import Question from "../Question/Question";
import Article from "../Article/Article";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
const Type = () => {
  const navigate = useNavigate();
  let [nowSelectType, setnowSelectType] = useState("Question");
  return (
    <>
      <div>
        <button
          className="back btn-6"
          onClick={() => {
            navigate("/");
          }}
        >
          <span>goBack</span>
        </button>
      </div>
      <div className="TypeBox">
        <div className="Head">New Post</div>
        <div className="Typesssss">
          <span className="marginR">Select Post Type</span>
          <span>
            <span>
              <input
                checked={nowSelectType === "Question"}
                name="type"
                type="radio"
                value="Question"
                onChange={() => {
                  setnowSelectType("Question");
                }}
              />
              Question
            </span>
            <span>
              <input
                checked={nowSelectType === "Article"}
                name="type"
                type="radio"
                value="Article"
                onChange={() => {
                  setnowSelectType("Article");
                }}
              />
              Article
            </span>
          </span>
        </div>
        {nowSelectType === "Question" ? (
          <>
            <Question></Question>
          </>
        ) : (
          <>
            <Article></Article>
          </>
        )}
      </div>
    </>
  );
};

export default Type;
