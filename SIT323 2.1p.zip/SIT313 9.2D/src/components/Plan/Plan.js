import "./Plan.css";
import { useNavigate } from "react-router-dom";
const Plan = () => {
  const navigate = useNavigate();
  return (
    <>
      <div className="bg"></div>
      <div className="Plan">
        <div className="BoxLeft">
          <div className="TiHead">Free Plan</div>
          <div className="TiCenter">
            <ul>
              <li className="Color">Allow Post</li>
              <li className="Color">Allow User Email</li>
              <li className="Color">Allow Check Quetion</li>
            </ul>
          </div>
          <div className="BTNB">
            <button className="btn-8 SpecialBtn BTNW">subscribe</button>
          </div>
        </div>
        <div className="BoxRight">
          <div className="TiHead">Premium  Plan</div>
          <div className="TiCenter">
            <ul>
              <li className="Color">Content controls</li>
              <li className="Color">Analytics dashborad</li>
              <li className="Color">More themes</li>
            </ul>
          </div>
          <div className="BTNB">
            <button className="btn-8 SpecialBtn BTNW" onClick={()=>{
                navigate('/Pay')
            }}>subscribe</button>
          </div>
        </div>
      </div>
    </>
  );
};

export default Plan;
