import './Pay.css'

const Pay = () => {
    return <>
        <div className="bg"></div>
        <div className='www'>
            <h2 className='payinfo'>Please Use Wechat Pay</h2>
            <img className='payimg' src={require('../../statis/wx.jpg')} alt=''></img>
        </div>
    </>
}

export default Pay;