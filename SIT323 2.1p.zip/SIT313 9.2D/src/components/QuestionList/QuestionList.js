import "./QuestionList.css";
import { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
const QuestionList = () => {
  const navigate = useNavigate();
  let [isShowMore, setisShowMore] = useState("");
  let [questionList, setQuestionList] = useState([]);
  let [answer, setanswer] = useState("");

  let [editId, seteditId] = useState(-1);

  let [time, settime] = useState("");
  let [tag, settag] = useState("");
  let [title, settitle] = useState("");

  useEffect(() => {
    getList();
  }, []);

  const getList = () => {
    axios
      .get("https://119.91.31.118:7001/api/userManage/getQuestion")
      .then((res) => {
        console.log(res, "resres");
        for (let i = 0; i < res.data.data.length; i++) {
          res.data.data[i]["isShowMore"] = false;
        }
        setQuestionList(res.data.data);
      });
  };

  const showMore = (id) => {
    console.log(id, "id");
    let copy = [...questionList];
    for (let i = 0; i < copy.length; i++) {
      if (copy[i].id === id) {
        copy[i].isShowMore = true;
      } else {
        copy[i].isShowMore = false;
      }
    }
    setQuestionList([...copy]);
  };

  const toAnswer = (id) => {
    seteditId(id);
    if (!localStorage.getItem("UserInfo")) {
      alert("please login");
      return;
    }
    if (answer === "") {
      alert("at least in one word");
      return;
    }
    axios
      .post("https://119.91.31.118:7001/api/userManage/commentQuestion", {
        forqid: id,
        answer: answer,
        name: JSON.parse(localStorage.getItem("UserInfo")).data.name,
      })
      .then((res) => {
        if (res.data.data) {
          alert("answer success");
          getList();
        }
      });
  };
  const deleteItem = (id) => {
    axios
      .post("https://119.91.31.118:7001/api/userManage/deleteQuestion", {
        id: id,
      })
      .then((res) => {
        if (res.data.data) {
          alert("delete success");
          getList();
        }
      });
  };
  const searchList = () => {
    let copy = [...questionList];
    if (time !== "" && tag === "" && title === "") {
      copy = copy.filter((item) => {
        return item.time.substring(0, 10) === time;
      });
      setQuestionList([...copy]);
    }
    if (time === "" && tag !== "" && title === "") {
      copy = copy.filter((item) => {
        return item.tag.indexOf(tag) !== -1;
      });
      setQuestionList([...copy]);
    }
    if (time === "" && tag === "" && title !== "") {
      copy = copy.filter((item) => {
        return item.title.indexOf(title) !== -1;
      });
      setQuestionList([...copy]);
    }
    if (time !== "" && tag !== "" && title !== "") {
      copy = copy.filter((item) => {
        return (
          item.time.substring(0, 10) === time &&
          item.tag.indexOf(tag) !== -1 &&
          item.title.indexOf(title) !== -1
        );
      });
      setQuestionList([...copy]);
    }
    console.log(questionList);
  };
  return (
    <>
    <div className="bgbg"></div>
      <button
        className="btn-8 SpecialBtn"
        onClick={() => {
          navigate("/");
        }}
      >
        <span>back</span>
      </button>
      <div className="QuestionList">
        <h2>QuestionList</h2>
        <div className="filter">
          <div className="fItem">
            <span>Date</span>
            <span>
              <input
                onChange={(e) => {
                  console.log(e.target.value, "e");
                  settime(e.target.value);
                }}
                type="date"
                placeholder="date filter"
                value={time}
              />
            </span>
          </div>
          <div className="fItem">
            <span>Tag</span>
            <span>
              <input
                onChange={(e) => {
                  settag(e.target.value);
                }}
                type="text"
                placeholder="tag filter"
                value={tag}
              />
            </span>
          </div>
          <div className="fItem">
            <span>Title</span>
            <span>
              <input
                onChange={(e) => {
                  settitle(e.target.value);
                }}
                type="text"
                placeholder="title filter"
                value={title}
              />
            </span>
          </div>
          <div className="fItem">
            <button
              className="btn-8 soBtn"
              onClick={() => {
                searchList();
              }}
            >
              <span>search</span>
            </button>
            <button
              className="btn-8 soBtn"
              onClick={() => {
                settime("");
                settag("");
                settitle("");
                getList();
              }}
            >
              <span>reload</span>
            </button>
          </div>
        </div>
        <div className="list">
          {questionList.length > 0 &&
            questionList.map((item) => {
              return (
                <>
                  <div
                    className={`eQuestion ${
                      item.isShowMore === true ? "AeQuestion" : ""
                    }`}
                    key={item.id}
                  >
                    <div className="group">
                      <button
                        className="btn-8 oopp"
                        onClick={() => {
                          showMore(item.id);
                        }}
                      >
                        <span>More Info</span>
                      </button>
                      <button
                        className="btn-8 oopp"
                        onClick={() => {
                          deleteItem(item.id);
                        }}
                      >
                        <span>Delete</span>
                      </button>
                    </div>
                    <div className="qImg">
                      <img className="Qimg" src={item.img} alt="" />
                    </div>
                    <div className="qTitle">Question Title ：{item.title}</div>
                    <div className="qTitle">
                      Question Problem ：{item.problem}
                    </div>
                    {/* <div dangerouslySetInnerHTML={{__html:item.problem}}></div> */}
                    <div className="qTitle">Question Tag ：{item.tag}</div>
                    <div className="qTitle">Question Date ：{item.time}</div>
                    {item.isShowMore === true && (
                      <>
                        <div className="CBox">
                          {item.qcomments.length > 0 &&
                            item.qcomments.map((item) => {
                              return (
                                <>
                                  <div className="cItem" key={item.id}>
                                    {item.name}：{item.text}
                                  </div>
                                </>
                              );
                            })}
                        </div>
                        <div className="cAnswer">
                          <span>
                            <input
                              onChange={(e) => {
                                setanswer(e.target.value);
                              }}
                              type="text"
                              placeholder="answer"
                              className="inpitoo"
                            ></input>
                          </span>
                          <span>
                            <button
                              className="btn-8 ppoo"
                              onClick={() => {
                                toAnswer(item.id);
                              }}
                            >
                              <span>answer</span>
                            </button>
                          </span>
                        </div>
                      </>
                    )}
                  </div>
                </>
              );
            })}
        </div>
      </div>
    </>
  );
};

export default QuestionList;
