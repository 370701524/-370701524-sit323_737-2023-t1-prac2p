import "./Regist.css";
import axios from 'axios'
import { useState } from "react";
import { useNavigate  } from "react-router-dom";
const Regist = () => {
  let [name,setname] = useState('')
  let [email,setemail] = useState('')
  let [password,setpassword] = useState('')
  let [confirmPassword,setconfirmPassword] = useState('')
  const navigate = useNavigate();
  const registUser = () => {
    if(password !== confirmPassword){
      alert('Two times password value was different !')
      return;
    }
    axios.post('https://119.91.31.118:7001/api/userManage/loginUser',{
      outType:2,
      name:name,
      email:email,
      password:password
    }).then(res=>{
      console.log(res,'rrrrwwww')
      if(res.data.code === 200 ){
        alert('注册成功')
        navigate('/Login')
      }
    })
  }
  return (
    <>
      <div className="RegistBox">
        <div className="Titless">Create a Dev@Deakin Account</div>
        <div className="From">
          <div className="FromItem">
            <span>Name*</span>
            <span>
              <input value={name} onChange={(e)=>{
                setname(e.target.value)
              }} className="inputR" placeholder="Enter Your Name" type="text" />
            </span>
          </div>
          <div className="FromItem">
            <span>Email*</span>
            <span>
              <input value={email} onChange={(e)=>{
                setemail(e.target.value)
              }} className="inputR" placeholder="Enter Your Email" type="text" />
            </span>
          </div>
          <div className="FromItem">
            <span>Password*</span>
            <span>
              <input value={password} onChange={(e)=>{
                setpassword(e.target.value)
              }} className="inputR" placeholder="Enter Your Password" type="password" />
            </span>
          </div>
          <div className="FromItem">
            <span>Confirm password*</span>
            <span>
              <input value={confirmPassword} onChange={(e)=>{
                setconfirmPassword(e.target.value)
              }} className="inputR" placeholder="Confirm Your password" type="password" />
            </span>
          </div>
        </div>
        <div className="SingBtn">
          <button className="signIn" onClick={registUser}>Regist</button>
        </div>
      </div>
    </>
  );
};

export default Regist;
