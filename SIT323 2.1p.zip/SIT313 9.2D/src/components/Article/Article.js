import "./Article.css";

const Article = () => {
  return (
    <>
      <div className="articleBox">
        <div className="Head">What do you want to ask or share</div>
        <div className="Title">
          <span className="marginR">Title</span>
          <input
            placeholder="Start your question with how, what, why, etc."
            className="input"
          />
        </div>
        <div className="postImg">
          <span className="title">Add an image</span>
          <span><input placeholder="post image" type="text" className="add"/><span className="btntext">Browse</span><span className="btntext">Upload</span></span>
          <input placeholder="post image" type="file" className="opacity"/>
        </div>
        <div className="Abstract">
          <div>Abstract</div>
          <div>
            <textarea
              className="textareaAbstract"
              placeholder="enter a 1-paragraph abstract"
            ></textarea>
          </div>
        </div>
        <div className="Article">
          <div>Article Text</div>
          <div>
            <textarea
              className="textareaArticle"
              placeholder="enter an Article Text"
            ></textarea>
          </div>
        </div>
        <div className="Tag">
          <span className="marginR">Tags</span>
          <span>
            {" "}
            <input
              placeholder="Start your question with how, what, why, etc."
              className="input"
            />
          </span>
        </div>
        <div className="BTN">
          <button className="btn">Post</button>
        </div>
      </div>
    </>
  );
};

export default Article;
