import Footer from "../Footer/Footer";
import Header from "..//Header/Header";
import FArticle from "../FArticle/FArticle";
import FTutorias from "../FTutorias/FTutorias";
const Home = () => {
  return (
    <>
      <Header></Header>
      <FArticle></FArticle>
      <FTutorias></FTutorias>
      <Footer></Footer>
    </>
  );
};

export default Home;
