import "./Question.css";
import axios from "axios";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import ReactMarkdown from "react-markdown";
import Editor from "for-editor";
const Question = () => {
  const navigate = useNavigate();
  let [fileName, setFileName] = useState("");
  let [file, setFile] = useState("");
  let [brow, setBrow] = useState("");
  let [showBorw, setShowBorw] = useState(false);
  let [fileSrc, setfileSrc] = useState(false);

  let [qTitle, setqTitle] = useState("");
  let [qProblem, setqProblem] = useState("");
  let [qTag, setqTag] = useState("");
  const getUploadImage = (e) => {
    console.log(e.target.files, "e");
    let file = e.target.files[0];
    console.log(file, "e");
    setFileName(file.name);
    setFile(file);
    let src = window.URL.createObjectURL(file);
    console.log(src, "src");
    setBrow(src);
  };

  const upload = () => {
    if (fileName === "") {
      alert("no select");
      return;
    }
    let form = new FormData();
    form.append("file", file);
    axios
      .post("https://119.91.31.118:7001/api/userManage/upload", form)
      .then((res) => {
        console.log(res, "resres");
        setfileSrc(res.data.url);
        if (res.data) {
          alert("upload success");
        }
      });
  };

  const Post = () => {
    console.log(fileSrc, "fileSrc");
    if (!localStorage.getItem("UserInfo")) {
      alert("please login");
      return;
    }
    let name = JSON.parse(localStorage.getItem("UserInfo")).data.name;
    let email = JSON.parse(localStorage.getItem("UserInfo")).data.email;
    let password = JSON.parse(localStorage.getItem("UserInfo")).data.password;
    let type = "Question";
    let title = qTitle;
    let img = fileSrc;
    let problem = qProblem;
    let tag = qTag;
    let date = new Date();
    let y = date.getFullYear();
    let m = date.getMonth() + 1;
    if (m <= 9) {
      m = "0" + m;
    }
    let d = date.getDate();
    if (d <= 9) {
      d = "0" + d;
    }
    let h = date.getHours();
    let min = date.getMinutes();
    let s = date.getSeconds();
    let srting = y + "-" + m + "-" + d + " " + h + ":" + min + ":" + s;
    let time = srting;
    console.log(name, email, password, type, title, img, problem, tag, time);
    if (img === false) {
      alert("img no upload pleace click upload img text first");
      return;
    }
    axios
      .post("https://119.91.31.118:7001/api/userManage/postQuestion", {
        name,
        email,
        password,
        type,
        title,
        img,
        problem,
        tag,
        time,
      })
      .then((res) => {
        console.log(res, "+++");
        if (res.data) {
          alert("question post success");
          navigate("/toQuestionList");
        }
      });
  };
  return (
    <>
      {showBorw === true && (
        <div className="browBox">
          <div className="ccchild">
            <button
              onClick={() => {
                setShowBorw(false);
              }}
            >
              Close Browse
            </button>
            <img className="imgborw" src={brow} alt=""></img>
          </div>
        </div>
      )}
      <div className="questionBox">
        <div className="Head">What do you want to share</div>
        <div className="Titlewwss">
          <span className="marginR">Title</span>
          <input
            placeholder="Start your question with how, what, why, etc."
            className="input"
            onChange={(e) => {
              setqTitle(e.target.value);
            }}
          />
        </div>
        <div className="postImg">
          <span className="title">Add an image</span>
          <span>
            <input
              value={fileName}
              placeholder="post image"
              type="text"
              className="add"
            />
            <button
              className="btntext btn-6"
              onClick={() => {
                if (fileName === "") {
                  alert("no upload");
                  return;
                }
                setShowBorw(true);
              }}
            >
              <span>Browse</span>
            </button>
            <button
              className="btntext btn-6"
              onClick={() => {
                upload();
              }}
            >
              <span>Upload</span>
            </button>
          </span>
          <input
            placeholder="post image"
            type="file"
            className="opacity"
            onChange={(e) => {
              getUploadImage(e);
            }}
          />
        </div>
        <div className="Problem">
          <div>Describe Your Problem</div>
          <div>
            {/* <textarea
              className="textarea"
              placeholder="write your Problem"
              onChange={(e) => {
                setqProblem(e.target.value);
              }}
            ></textarea> */}
            <Editor
              onChange={(e) => {
                console.log(e);
                setqProblem(e);
              }}
            />
          </div>
        </div>
        <div className="Tag">
          <span className="marginR">Tags</span>
          <span>
            {" "}
            <input
              placeholder="question tag and please split ','"
              className="input"
              onChange={(e) => {
                setqTag(e.target.value);
              }}
            />
          </span>
        </div>
        <div className="BTN">
          <button
            className="btn"
            onClick={() => {
              Post();
            }}
          >
            Post
          </button>
        </div>
      </div>
    </>
  );
};

export default Question;
