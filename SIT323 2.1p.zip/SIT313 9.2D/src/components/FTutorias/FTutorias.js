import "./FTutorias.css";
import { useState } from "react";
const FTutorias = () => {
  let [tutorial] = useState([
    {
      AImg: require("../../statis/images/Article image4.jpg"),
      AName: "Tutorial's Name",
      ADescription: "Description _ _ _ _ _",
      ATag: "e.g.， JS6",
      ALike: 5,
      AUserName: "username",
    },
    {
      AImg: require("../../statis/images/Article image5.jpg"),
      AName: "Tutorial's Name",
      ADescription: "Description _ _ _ _ _",
      ATag: "e.g.， React Router",
      ALike: 5,
      AUserName: "username",
    },
    {
      AImg: require("../../statis/images/Article image6.jpg"),
      AName: "Tutorial's Name",
      ADescription: "Description _ _ _ _ _",
      ATag: "e.g.， Express",
      ALike: 5,
      AUserName: "username",
    },
  ]);
  return (
    <>
      <div className="FTutoriasBox">
        <div className="Typess">Featured Tutorias</div>
        <div className="ItemBox">
          {tutorial.length > 0 &&
            tutorial.map((item) => {
              return (
                <div className="EachItem" key={item.id}>
                  <div className="Top">
                    <img className="articleImg" src={item.AImg} alt=""></img>
                  </div>
                  <div className="Bottom">
                    <div className="AName">{item.AName}</div>
                    <div className="ADescription">{item.ADescription}</div>
                    <div className="ATag">{item.ATag}</div>
                    <div className="ASplit"></div>
                    <div className="AInfo">
                      <div className="LeftB">
                        <img
                          className="star"
                          src={require("../../statis/images/star.png")}
                          alt=""
                        ></img>
                        <span className="ALike">{item.ALike}</span>
                      </div>
                      <div className="RightB">{item.AUserName}</div>
                    </div>
                  </div>
                </div>
              );
            })}
        </div>
        <div className="AMore">
          <button className="SeeMore"> See all tutorials</button>
        </div>
      </div>
    </>
  );
};

export default FTutorias;
