import "./App.css";
// import Type from "./components/Type/Type";
// import Question from "./components/Question/Question";
// import Article from "./components/Article/Article";
import Login from "./components/Login/Login";
import Regist from "./components/Regist/Regist";
import Home from "./components/Home/Home";
import Type from "./components/Type/Type";
import QuestionList from "./components/QuestionList/QuestionList";
import Plan from "./components/Plan/Plan";
import Pay from "./components/Pay/Pay";
// import ReactMarkdown from 'react-markdown'
// import Editor from 'for-editor'


import { BrowserRouter, Routes, Route } from "react-router-dom";
function App() {
  return (
    <div className="App">
      {/* <div dangerouslySetInnerHTML={{__html:value}}></div>
      <button onClick={()=>{
        console.log(value,'www')
      }}>get</button>
      <ReactMarkdown>*React-Markdown* is **Awesome**</ReactMarkdown>
      <Editor onChange={(e) => {
        console.log(e)
        setvalue(e)
      }} /> */}
      <div className="ChildFatherBox">
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<Home />} /> 
              <Route path="/Login" element={<Login />} />
              <Route path="/Regist" element={<Regist />} />
              <Route path="/toPost" element={<Type />} />
              <Route path="/toQuestionList" element={<QuestionList />} />
              <Route path="/Plan" element={<Plan />} />
              <Route path="/Pay" element={<Pay />} />
            </Routes>
          </BrowserRouter>
      </div>
    </div>
  );
}

export default App;
